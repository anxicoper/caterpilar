$(function() {  
    $('#restore').hide();
    $("#transform").on('click', function() {
        // Add your code here
    });

    $("#restore").on('click', function() {
        location.reload(true); 
    }); 

});